<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\HeaderController;
use App\Http\Controllers\Admin\RoleController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\SupplierController;
use App\Http\Controllers\Admin\BookingDeliveryDestinationController;
use App\Http\Controllers\Admin\BookingInstructionController;
use App\Http\Controllers\Admin\PoGenerateControlController;

Route::prefix('admin')
    ->middleware(['auth', 'role:admin'])
    ->name('admin.')
    ->group(function () {
        Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

        Route::resource('users', UserController::class)->except(['show']);
        Route::resource('roles', RoleController::class)->except(['show']);
        Route::resource('headers', HeaderController::class)->except(['show']);

        Route::resource('suppliers', SupplierController::class)->except(['show']);
        Route::resource('booking-delivery-destinations', BookingDeliveryDestinationController::class)->except(['show']);
        Route::resource('booking-instructions', BookingInstructionController::class)->except(['show']);

        Route::get('/po-generate-control', [PoGenerateControlController::class, 'index'])->name('po-generate-control.index');
        Route::get('/po-generate-control/pending', [PoGenerateControlController::class, 'pending'])->name('po-generate-control.pending');
        Route::get('/po-generate-control/generated', [PoGenerateControlController::class, 'generated'])->name('po-generate-control.generated');
        Route::get('/po-generate-control/po/{bookingPo}', [PoGenerateControlController::class, 'show'])->name('po-generate-control.show');
        Route::post('/po-generate-control/po/{bookingPo}/edit-preview', [PoGenerateControlController::class, 'editPreview'])->name('po-generate-control.edit_preview');
        Route::post('/po-generate-control/po/{bookingPo}/update', [PoGenerateControlController::class, 'update'])->name('po-generate-control.update');
        Route::patch('/po-generate-control/po/{bookingPo}/access', [PoGenerateControlController::class, 'saveAccess'])->name('po-generate-control.access');
        Route::delete('/po-generate-control/po/{bookingPo}', [PoGenerateControlController::class, 'destroy'])->name('po-generate-control.destroy');
        Route::post('/po-generate-control/po/{bookingPo}/regenerate-preview', [PoGenerateControlController::class, 'regeneratePreview'])->name('po-generate-control.regenerate_preview');
        Route::post('/po-generate-control/po/{bookingPo}/regenerate', [PoGenerateControlController::class, 'regenerate'])->name('po-generate-control.regenerate');
        Route::get('/po-generate-control/po/{bookingPo}/print', [PoGenerateControlController::class, 'print'])->name('po-generate-control.print');
        Route::get('/po-generate-control/po/{bookingPo}/download', [PoGenerateControlController::class, 'download'])->name('po-generate-control.download');
        Route::get('/po-generate-control/po/{bookingPo}/download-excel', [PoGenerateControlController::class, 'downloadExcel'])->name('po-generate-control.download_excel');
        
        Route::get('/workspace', [DashboardController::class, 'workspace'])->name('workspace');
    });